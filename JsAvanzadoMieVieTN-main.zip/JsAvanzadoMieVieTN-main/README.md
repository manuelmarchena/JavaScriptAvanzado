# JsAvanzadoMieVieTN
Curso de JS Avanzado Educacion IT 15 -9 - 2021 
